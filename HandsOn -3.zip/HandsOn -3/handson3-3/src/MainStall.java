import java.util.*;
public class MainStall {

	public static void main(String[] args) {
		Stall s = new Stall();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the name:");
		String name = sc.nextLine();
		System.out.println("enter owner name:");
		String ownername = sc.nextLine();
		System.out.println("enter the detail:");
		String detail = sc.nextLine();
		System.out.println("enter the type of stall:");
		String type = sc.nextLine();
		System.out.println("enter the size of the hall in sq.ft:");
		int size= sc.nextInt();
		System.out.println("Does stall have the Tv(yes/no)");
		int tv = sc.nextInt();
		
		if(tv == 1) {
			
			System.out.println("enter the no. of TV:");
			int no = sc.nextInt();
			double amount =s.computeCost(type,size,no);
			System.out.println(amount);
			
		}
		else {
			double cost =s.computeCost(type,size);
			System.out.println(cost);
		}
	}

}
