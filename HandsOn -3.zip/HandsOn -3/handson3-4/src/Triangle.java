
public class Triangle extends Area {
double base;
double height;

public Triangle() {
	
}

public Triangle(double base, double height) {
	super();
	this.base = base;
	this.height = height;
}

public double getBase() {
	return base;
}

public void setBase(double base) {
	this.base = base;
}

public double getHeight() {
	return height;
}

public void setHeight(double height) {
	this.height = height;
}

public void computeArea(){
	area = 0.05*base*height;
	System.out.println("area of triangle:"+area);
}
}
