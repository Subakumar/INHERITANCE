
public class Rectangle extends Area{
double length;
double breadth;

public Rectangle() {
	
}

public Rectangle(double length, double breadth) {
	super();
	this.length = length;
	this.breadth = breadth;
}

public double getLength() {
	return length;
}

public void setLength(double length) {
	this.length = length;
}

public double getBreadth() {
	return breadth;
}

public void setBreadth(double breadth) {
	this.breadth = breadth;
}
public void computeArea() {
	area= length*breadth;
	System.out.println("area of rectangle:"+area);
	
}
}
