
public class Acc {

	protected String accname;
	protected String accno;
	protected String bankname;
	
	
 public	Acc(){
		
	}


public Acc(String accname, String accno, String bankname) {
	super();
	this.accname = accname;
	this.accno = accno;
	this.bankname = bankname;
}

public String getAccname() {
	return accname;
}


public void setAccname(String accname) {
	this.accname = accname;
}


public String getAccno() {
	return accno;
}


public void setAccno(String accno) {
	this.accno = accno;
}


public String getBankname() {
	return bankname;
}


public void setBankname(String bankname) {
	this.bankname = bankname;
}
 
void display() {
	System.out.println("Account Name:"+getAccname());
	System.out.println("Account number:"+getAccno());
	System.out.println("Bank Name:"+getBankname());
}

		
		


}
	
	

	
	
