import java.util.*;
public class Acc1Main {

	public static void main(String[] args) {
		Acc1 a = new Acc1();
		FixedAccount f1 = new FixedAccount();
		Scanner s = new Scanner (System.in);
		System.out.println("enter the account detail:");
		String detail = s.nextLine();
		String str[] = detail.split(",");
		for(String ss:str)
			System.out.println("");
		String accountnumber = str[0];
		double balance = Double.parseDouble(str[1]);
		String accountHolderName = str[2];
		double minimumbalance =Double.parseDouble(str[3]);
		int lockingperiod =Integer.parseInt(str[4]);
			f1.setAccountNumber(accountnumber);
			f1.setBalance(balance);
			f1.setAccountHolderName(accountHolderName);
			f1.setMinimumbalance(minimumbalance);
			f1.setLockingperiod(lockingperiod);
			System.out.format("%-20s %-10s %-20s %-20s %s\n","Account Number","Balance","Account holder name","Minimum balance","Locking period");
			
		System.out.println(f1.getAccountNumber()+"\t"+f1.getBalance()+"\t"+f1.getAccountHolderName()+"\t"+f1.getMinimumbalance()+"\t"+f1.getLockingperiod());
		
		
		
	}

}
